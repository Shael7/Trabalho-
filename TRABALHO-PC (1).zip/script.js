function scrollToTeam() {
    const teamSection = document.getElementById('team');
    teamSection.scrollIntoView({ behavior: 'smooth' });
}